Features:
Multi-language
Reports, short transactions summaries, printing, exporting.
Scheduled transactions
Category sorting
Multiple accounts
Multiple currencies
Calculator
Database automatic repairer (debugger)
Custom thousand,decimal separators
Multiple interface skins

All icons found in date\ (except for splash) folder are commercial free and distribuable and downloaded from iconfinder.com.
Splash image(s) (date\splash) are CC0 images downloaded from pixabay.com.
Category images stored in ImageLists and any other images stored application source are free for commercial use and non-distribuable.

Install sharew component which and drop it on mainform (FP) to enable trial mode. _LICENSE_gen is
a generator designed to generate license codes based on Name and Auth Code.

Almost all comments are in Romanian.